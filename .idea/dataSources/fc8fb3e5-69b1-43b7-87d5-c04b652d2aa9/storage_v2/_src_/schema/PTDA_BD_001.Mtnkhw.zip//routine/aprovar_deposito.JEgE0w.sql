create
    definer = PTDA_001@`%` procedure aprovar_deposito(IN depostio int, IN funcionario int)
BEGIN
        DECLARE EXIT HANDLER FOR SQLEXCEPTION
            BEGIN
                ROLLBACK;
                RESIGNAL;
            END;
        START TRANSACTION;
            UPDATE cliente SET saldo_cativo = saldo_cativo - (select valor from deposito where id_deposito = depostio)
                           WHERE num_cliente = (SELECT num_cli from deposito where id_deposito = depostio);

            UPDATE deposito SET aprovado = true, num_fun = funcionario, pendente_aprovacao = false WHERE id_deposito = depostio;

            INSERT INTO funcionario_cliente (num_fun, num_cli)
            VALUES (funcionario, (SELECT num_cli from deposito where id_deposito = depostio));

            INSERT INTO transacoes (num_cli, descricao, valor)
            VALUES ((SELECT num_cli from deposito where id_deposito = depostio), "Depostio", (select valor from deposito where id_deposito = depostio));
        COMMIT;
END;

