create
    definer = PTDA_001@`%` procedure reprovar_deposito(IN depostio int, IN funcionario int)
BEGIN
    UPDATE cliente SET saldo_cativo = saldo_cativo - (select valor from deposito where id_deposito = depostio) WHERE num_cliente = (SELECT num_cli from deposito where id_deposito = depostio);

    UPDATE deposito SET aprovado = false, num_fun = funcionario, pendente_aprovacao = false WHERE id_deposito = depostio;

    INSERT INTO funcionario_cliente (num_fun, num_cli) VALUES (funcionario, (SELECT num_cli from deposito where id_deposito = depostio));
END;

