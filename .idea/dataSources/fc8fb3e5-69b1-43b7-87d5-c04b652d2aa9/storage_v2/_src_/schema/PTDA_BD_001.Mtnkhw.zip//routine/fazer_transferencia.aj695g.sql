create
    definer = PTDA_001@`%` procedure fazer_transferencia(IN cliente_envia int, IN cliente_recetor int,
                                                         IN valor_trans decimal(10, 2), IN descricao varchar(255))
BEGIN
        DECLARE EXIT HANDLER FOR SQLEXCEPTION
            BEGIN
                ROLLBACK;
                RESIGNAL;
            END;
        START TRANSACTION;
            INSERT INTO transferencia (valor, cliente_realiza, cliente_recebe, motivo) VALUES (valor_trans, cliente_envia, cliente_recetor,descricao);

            INSERT INTO transacoes (num_cli, descricao, valor) VALUES (cliente_envia, "Transferencia", 0 - valor_trans);
            INSERT INTO transacoes (num_cli, descricao, valor) VALUES (cliente_recetor, "Transferencia", valor_trans);
        COMMIT;
END;

