create definer = PTDA_001@`%` trigger deposito
    after insert
    on deposito
    for each row
BEGIN
    DECLARE existe INT;

    -- Cria mais alguma segurança no trigger
    SELECT COUNT(*) INTO existe FROM cliente WHERE num_cliente = NEW.num_cli;

    IF existe > 0 THEN
        UPDATE cliente SET saldo_cativo = saldo_cativo + NEW.valor WHERE num_cliente = NEW.num_cli;
    END IF;
END;

