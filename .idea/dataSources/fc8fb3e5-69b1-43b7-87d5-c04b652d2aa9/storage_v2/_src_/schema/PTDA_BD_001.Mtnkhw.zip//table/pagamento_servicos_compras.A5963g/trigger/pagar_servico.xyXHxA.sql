create definer = PTDA_001@`%` trigger pagar_servico
    after update
    on pagamento_servicos_compras
    for each row
BEGIN
    DECLARE existe INT;
    DECLARE saldo DECIMAL(10, 2);

    -- Cria mais alguma segurança no trigger
    SELECT COUNT(*) INTO existe FROM cliente WHERE num_cliente = NEW.cliente;
    SELECT cliente.saldo INTO saldo FROM cliente WHERE num_cliente = NEW.cliente;

    IF existe > 0 THEN
        IF saldo >= NEW.valor THEN
            INSERT INTO transacoes (num_cli, descricao, valor)
            VALUES (NEW.cliente, "Pagamento serviços", 0 - NEW.valor);

            INSERT INTO transacoes (num_cli, descricao, valor)
            VALUES (NEW.cliente_cria, "Pagamento serviços", NEW.valor);
        END IF;
    END IF;
END;

